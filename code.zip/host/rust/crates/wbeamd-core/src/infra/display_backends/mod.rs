use super::host_probe::{HostOs, HostProbe};
#[cfg(unix)]
use super::x11_monitor_object;
#[cfg(unix)]
use super::x11_real_output;

#[cfg(unix)]
mod linux;
#[cfg(not(unix))]
mod linux {
    use super::{Activation, ActivationError, DisplayMode, HostProbe, VirtualMonitorProbe};

    pub fn probe_virtual_monitor(host_probe: &HostProbe) -> VirtualMonitorProbe {
        VirtualMonitorProbe {
            supported: false,
            resolver: "linux_backend_unavailable".to_string(),
            missing_deps: vec!["unix-runtime".to_string()],
            hint: format!(
                "Linux virtual monitor backend is unavailable on this platform (os={})",
                host_probe.os_name()
            ),
        }
    }

    pub fn activate(
        _host_probe: &HostProbe,
        mode: DisplayMode,
        _serial_hint: &str,
        _size: &str,
    ) -> Result<Activation, ActivationError> {
        if mode.is_virtual() {
            return Err(ActivationError::Unsupported(
                "Linux virtual monitor backend is unavailable on this platform".to_string(),
            ));
        }
        Ok(Activation::default())
    }
}
mod windows;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DisplayMode {
    Duplicate,
    VirtualMonitor,
    VirtualMirror,
}

impl DisplayMode {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Duplicate => "duplicate",
            Self::VirtualMonitor => "virtual_monitor",
            Self::VirtualMirror => "virtual_mirror",
        }
    }

    pub fn is_virtual(self) -> bool {
        !matches!(self, Self::Duplicate)
    }
}

#[derive(Debug, Clone)]
pub enum RuntimeHandle {
    #[cfg(unix)]
    X11RealOutput(x11_real_output::X11RealOutputHandle),
    #[cfg(unix)]
    X11MonitorObject(x11_monitor_object::X11MonitorObjectHandle),
}

#[derive(Debug, Clone, Default)]
pub struct Activation {
    pub display_override: Option<String>,
    pub capture_region: Option<(i32, i32, u32, u32)>,
    pub using_virtual_x11: bool,
    pub runtime_handle: Option<RuntimeHandle>,
}

#[derive(Debug, Clone)]
pub enum ActivationError {
    Unsupported(String),
    Failed(String),
}

#[derive(Debug, Clone)]
pub struct VirtualMonitorProbe {
    pub supported: bool,
    pub resolver: String,
    pub missing_deps: Vec<String>,
    pub hint: String,
}

pub fn normalize_requested_mode(mode: Option<&str>) -> DisplayMode {
    match mode.unwrap_or("duplicate").trim().to_lowercase().as_str() {
        "virtual" | "virtual_monitor" => DisplayMode::VirtualMonitor,
        "virtual_mirror" | "virtual-duplicate" | "virtual_duplicate" => DisplayMode::VirtualMirror,
        _ => DisplayMode::Duplicate,
    }
}

pub fn virtual_monitor_probe(host_probe: &HostProbe) -> VirtualMonitorProbe {
    match host_probe.os {
        HostOs::Linux => linux::probe_virtual_monitor(host_probe),
        HostOs::Windows => windows::probe_virtual_monitor(),
        _ => VirtualMonitorProbe {
            supported: false,
            resolver: "unsupported_host_backend".to_string(),
            missing_deps: Vec::new(),
            hint: format!(
                "Virtual monitor is unsupported on os={} session={}",
                host_probe.os_name(),
                host_probe.session_name()
            ),
        },
    }
}

pub fn activate_start(
    host_probe: &HostProbe,
    mode: DisplayMode,
    serial_hint: &str,
    size: &str,
) -> Result<Activation, ActivationError> {
    match host_probe.os {
        HostOs::Linux => linux::activate(host_probe, mode, serial_hint, size),
        HostOs::Windows => windows::activate(host_probe, mode, serial_hint, size),
        _ => {
            if mode.is_virtual() {
                Err(ActivationError::Unsupported(format!(
                    "virtual monitor mode unsupported on os={} session={}",
                    host_probe.os_name(),
                    host_probe.session_name()
                )))
            } else {
                Ok(Activation::default())
            }
        }
    }
}

pub async fn stop_runtime(handle: RuntimeHandle) {
    #[cfg(unix)]
    match handle {
        RuntimeHandle::X11RealOutput(h) => {
            let _ = x11_real_output::destroy(&h);
        }
        RuntimeHandle::X11MonitorObject(h) => {
            let _ = x11_monitor_object::destroy(&h);
        }
    }
    #[cfg(not(unix))]
    {
        let _ = handle;
    }
}
